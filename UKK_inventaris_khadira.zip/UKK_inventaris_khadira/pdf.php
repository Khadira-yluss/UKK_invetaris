<?php
include "koneksi.php";


$search          = isset($_GET['search']) ? trim($_GET['search']) : "";
$kategoriFilter  = isset($_GET['kategori_filter']) ? trim($_GET['kategori_filter']) : "";



$where = [];
$params = [];

if ($search !== "") {
    $where[] = "(barang.nama_barang LIKE ? OR kategori.nama_kategori LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($kategoriFilter !== "") {
    $where[] = "kategori.id_kategori = ?";
    $params[] = $kategoriFilter;
}

$whereSql = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";



$sql = "SELECT barang.*, kategori.nama_kategori
        FROM barang
        LEFT JOIN kategori ON barang.id_kategori = kategori.id_kategori
        $whereSql
        ORDER BY barang.id_barang ASC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Print / PDF - Data Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 25px;
            color: #222;
        }

        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .btn-back, .btn-print {
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-back {
            background: #6c757d;
            color: white;
        }

        .btn-back:hover {
            background: #5a6268;
        }

        .btn-print {
            background: #007bff;
            color: white;
        }

        .btn-print:hover {
            background: #0056b3;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th {
            background: #1e1e1e;
            color: white;
            padding: 10px;
            text-align: center;
        }

        td {
            padding: 8px;
            border: 1px solid #ccc;
            text-align: center;
        }

        tbody tr:nth-child(odd) {
            background-color: #f8f9fa;
        }

        tbody tr:nth-child(even) {
            background-color: #e9ecef;
        }

        h2 {
            text-align: center;
            margin-bottom: 15px;
        }

        @media print {
            .header-actions {
                display: none;
            }
        }
    </style>
</head>
<body>

    <div class="header-actions">
        <a href="print.php" class="btn-back">← Kembali</a>
        <button onclick="window.print()" class="btn-print">Print / Simpan PDF</button>
    </div>

    <h2>Data Barang</h2>

    <table>
        <thead>
            <tr>
                <th>ID Barang</th>
                <th>Nama Kategori</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Tanggal Masuk</th>
            </tr>
        </thead>

        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id_barang']) ?></td>
                <td><?= htmlspecialchars($row['nama_kategori'] ?? '-') ?></td>
                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                <td><?= htmlspecialchars($row['jumlah']) ?></td>
                <td><?= number_format($row['harga'], 0, ',', '.') ?></td>
                <td><?= htmlspecialchars($row['tgllmasuk'] ?? '-') ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>
