<?php
include 'koneksi.php';

// Ambil daftar kategori dari database
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

// Proses jika form disubmit
if (isset($_POST['simpan'])) {
    $kategori_id   = isset($_POST['kategori_id']) ? intval($_POST['kategori_id']) : 0;
    $nama_barang   = mysqli_real_escape_string($conn, trim($_POST['nama_barang']));
    $jumlah        = isset($_POST['jumlah']) ? intval($_POST['jumlah']) : 0;
    $harga         = isset($_POST['harga']) ? intval($_POST['harga']) : 0;
    $tgl           = isset($_POST['tgllmasuk']) ? $_POST['tgllmasuk'] : '';

    // Validasi sederhana
    $errors = [];
    if ($kategori_id == 0 || $nama_barang == "" || $jumlah <= 0 || $harga <= 0 || $tgl == "") {
        $errors[] = "Semua field wajib diisi!";
    }

    if (!empty($errors)) {
        $msg = implode("\\n", $errors);
        echo "<script>alert('$msg');</script>";
    } else {

        // INSERT sesuai dengan tabel gambar kamu
        $sql = "INSERT INTO barang (id_kategori, nama_barang, jumlah, harga, tglmasuk)
                VALUES (
                    '$kategori_id',
                    '$nama_barang',
                    '$jumlah',
                    '$harga',
                    '$tgl'
                )";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Barang berhasil ditambahkan!'); window.location='item.php';</script>";
        } else {
            echo "<script>alert('Gagal menyimpan data: ".mysqli_error($conn)."');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2 class="text-center mb-4">Tambah Barang Baru</h2>
    <div class="card shadow p-4">
        <form id="tambahForm" method="post">

            <div class="mb-3">
                <label class="form-label">Nama Kategori</label>
                <select name="kategori_id" class="form-select" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php while($row = mysqli_fetch_assoc($kategori)): ?>
                        <option value="<?= $row['id_kategori']; ?>">
                            <?= $row['nama_kategori']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Nama Barang</label>
                <input type="text" name="nama_barang" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Jumlah</label>
                <input type="number" name="jumlah" class="form-control" min="1" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga Barang (Rp)</label>
                <input type="number" name="harga" class="form-control" min="1" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Tanggal Masuk</label>
                <input type="date" name="tgllmasuk" class="form-control" required>
            </div>

            <div class="text-end">
                <a href="item.php" class="btn btn-secondary">Kembali</a>
                <button type="submit" name="simpan" class="btn btn-success">Simpan Barang</button>
            </div>

        </form>
    </div>
</div>

<script>
// Validasi JS
document.getElementById('tambahForm').addEventListener('submit', function(e){
    const kategori = document.querySelector('select[name="kategori_id"]').value;
    const nama = document.querySelector('input[name="nama_barang"]').value.trim();
    const jumlah = document.querySelector('input[name="jumlah"]').value;
    const harga = document.querySelector('input[name="harga"]').value;
    const tgl = document.querySelector('input[name="tgllmasuk"]').value;

    const errors = [];
    if (!kategori) errors.push("Pilih kategori.");
    if (!nama) errors.push("Nama barang wajib diisi.");
    if (jumlah === "" || isNaN(jumlah) || parseInt(jumlah) <= 0) errors.push("Jumlah harus angka lebih dari 0.");
    if (harga === "" || isNaN(harga) || parseInt(harga) <= 0) errors.push("Harga harus angka lebih dari 0.");
    if (!tgl) errors.push("Tanggal wajib diisi.");

    if (errors.length) {
        e.preventDefault();
        alert(errors.join("\n"));
    }
});
</script>

</body>
</html>
