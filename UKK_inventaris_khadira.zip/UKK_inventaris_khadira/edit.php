<?php 
include "koneksi.php";

// Pastikan ID ada
if (!isset($_GET['id'])) {
    echo "<script>alert('ID barang tidak ditemukan!'); window.location='item.php';</script>";
    exit;
}

$id = intval($_GET['id']);

// Ambil data barang + kategori
$query = mysqli_query($conn,
    "SELECT barang.*, kategori.nama_kategori 
     FROM barang 
     LEFT JOIN kategori ON barang.id_kategori = kategori.id_kategori
     WHERE barang.id_barang = $id"
);

$barang = mysqli_fetch_assoc($query);

if (!$barang) {
    echo "<script>alert('Data barang tidak ditemukan!'); window.location='item.php';</script>";
    exit;
}

// Ambil semua kategori
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

// ========== PROSES UPDATE ==========
if (isset($_POST['update'])) {
    $id_kategori   = $_POST['id_kategori'];
    $nama_barang   = $_POST['nama_barang'];
    $jumlah        = $_POST['jumlah'];
    $harga         = $_POST['harga'];
    $tanggal       = $_POST['tglmasuk']; // FIXED

    // Validasi
    $errors = [];

    if (!is_numeric($jumlah) || intval($jumlah) <= 0) {
        $errors[] = "Jumlah harus berupa angka valid.";
    }

    if (!is_numeric($harga) || floatval($harga) <= 0) {
        $errors[] = "Harga harus berupa angka valid.";
    }

    if (empty($errors)) {

        $sql = "UPDATE barang SET
                id_kategori = '".intval($id_kategori)."',
                nama_barang = '".mysqli_real_escape_string($conn, $nama_barang)."',
                jumlah      = '".intval($jumlah)."',
                harga       = '".floatval($harga)."',
                tglmasuk    = '".mysqli_real_escape_string($conn, $tanggal)."'  -- FIXED
                WHERE id_barang = $id";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Data berhasil diupdate!'); window.location='item.php';</script>";
        } else {
            echo "<script>alert('Gagal mengupdate data!');</script>";
        }

    } else {
        echo "<script>alert('".implode("\\n", $errors)."');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Barang</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card p-4 shadow-lg">
        <h3 class="mb-4 text-center">Edit Data Barang</h3>

        <form id="editForm" method="post">

            <!-- KATEGORI -->
            <label class="form-label">Kategori</label>
            <select name="id_kategori" class="form-select" required>
                <option value="">-- Pilih Kategori --</option>

                <?php while ($kt = mysqli_fetch_assoc($kategori)): ?>
                    <option value="<?= htmlspecialchars($kt['id_kategori'], ENT_QUOTES); ?>"
                        <?= ($barang['id_kategori'] == $kt['id_kategori']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($kt['nama_kategori'], ENT_QUOTES); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <!-- NAMA BARANG -->
            <label class="form-label mt-3">Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" 
                   value="<?= htmlspecialchars($barang['nama_barang'], ENT_QUOTES); ?>" required>

            <!-- JUMLAH -->
            <label class="form-label mt-3">Jumlah</label>
            <input type="number" name="jumlah" class="form-control" min="1"
                   value="<?= htmlspecialchars($barang['jumlah'], ENT_QUOTES); ?>" required>

            <!-- HARGA -->
            <label class="form-label mt-3">Harga</label>
            <input type="number" name="harga" class="form-control" min="1" step="0.01"
                   value="<?= htmlspecialchars($barang['harga'], ENT_QUOTES); ?>" required>

            <!-- TANGGAL -->
            <label class="form-label mt-3">Tanggal Masuk</label>
            <input type="date" name="tglmasuk" class="form-control" 
                   value="<?= htmlspecialchars($barang['tglmasuk'], ENT_QUOTES); ?>" required> <!-- FIXED -->

            <div class="mt-4 d-flex gap-2">
                <button type="submit" name="update" class="btn btn-primary">
                    <i class="fa-solid fa-check"></i> Simpan Perubahan
                </button>

                <a href="item.php" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Kembali
                </a>
            </div>

        </form>

    </div>
</div>

<script>
// Client-side validation: jumlah & harga harus > 0
document.getElementById('editForm').addEventListener('submit', function(e){
    const jumlahEl = document.querySelector('input[name="jumlah"]');
    const hargaEl = document.querySelector('input[name="harga"]');
    const jumlah = jumlahEl.value;
    const harga = hargaEl.value;
    const errors = [];

    if (jumlah === "" || isNaN(jumlah) || parseInt(jumlah) <= 0) {
        errors.push("Jumlah harus berupa angka bulat dan lebih dari 0.");
    }
    if (harga === "" || isNaN(harga) || parseFloat(harga) <= 0) {
        errors.push("Harga harus berupa angka dan lebih dari 0.");
    }

    if (errors.length) {
        e.preventDefault();
        alert(errors.join("\\n"));
        if (parseInt(jumlah) <= 0) jumlahEl.focus(); else hargaEl.focus();
    }
});
</script>

</body>
</html>
