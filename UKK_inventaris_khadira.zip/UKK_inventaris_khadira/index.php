<?php
include "koneksi.php";

// move filter logic before chart so chart follows same filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : "";
$kategoriFilter = isset($_GET['kategori_filter']) ? mysqli_real_escape_string($conn, $_GET['kategori_filter']) : "";
$where = [];
if ($search != "") $where[] = "(nama_barang LIKE '%$search%' OR nama_kategori LIKE '%$search%')";
if ($kategoriFilter != "") $where[] = "nama_kategori = '$kategoriFilter'";
$whereSql = count($where) > 0 ? "WHERE ".implode(" AND ", $where) : "";

// Ambil data untuk chart per barang (nama barang di X, jumlah di Y)
$namaData = [];
$jumlahData = [];
$chartQuery = "SELECT nama_barang, jumlah FROM barang $whereSql ORDER BY id_barang ASC";
$resultChart = $conn->query($chartQuery);

$totalBarang = 0;
while ($row = $resultChart->fetch_assoc()) {
    $namaData[] = $row['nama_barang'];
    $jumlahData[] = (int)$row['jumlah'];
    $totalBarang += (int)$row['jumlah'];
}

// Filter tabel
$resultTable = $conn->query("SELECT * FROM barang $whereSql ORDER BY id_barang ASC");

// Dropdown kategori
$kategoriResult = $conn->query("SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Inventaris</title>
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
#sidebar.collapsed { width: 80px; }
#sidebar .menu-text { transition: 0.3s; opacity: 1; }
#sidebar.collapsed .menu-text { opacity: 0; }
#content { margin-left: 260px; transition: all 0.3s ease; padding:40px 20px 20px 20px; }
#content.collapsed { margin-left: 80px; }
#toggle-btn { position: fixed; top: 10px; left: 270px; cursor: pointer; z-index: 1200; }
#content.collapsed + #toggle-btn { left: 90px; }

/* Chart container lebih kecil */
.chart-section {
    height: 300px; /* lebih kecil supaya tidak menutupi garis */
    position: relative;
    z-index: 1;
}

/* TABEL */
table {
    width: 100%;
    border-collapse: collapse;
}
th {
    background-color: #1e1e1e; /* hanya header tabel berwarna */
    color: white;
    padding: 10px;
    text-align: center;
}
td {
    padding: 8px;
    border: 1px solid #ccc;
    text-align: center;
    background-color: white; /* baris data tetap putih */
}

/* Tombol */
.top-btn { display:flex; justify-content:space-between; margin-bottom:15px; }
.btn { padding:10px 15px; border:none; color:white; border-radius:5px; cursor:pointer; text-decoration:none; }
.btn-kembali { background:#4caf50; }
.btn-kembali:hover { background:#45a049; }
.btn-excel { background:#2196f3; }
.btn-excel:hover { background:#1976d2; }

</style>
</head>
<body>

<!-- SIDEBAR -->
<div id="sidebar" class="p-3">
    <h4 class="menu-text">Menu</h4>
    <ul class="nav flex-column mt-4">
        <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span class="menu-text">Dashboard</span></a></li>
        <li><a href="item.php"><i class="fa-solid fa-screwdriver-wrench"></i> <span class="menu-text">Update</span></a></li>
        <li><a href="print.php"><i class="fa-solid fa-file-lines"></i> <span class="menu-text">Print</span></a></li>
        <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span class="menu-text">Logout</span></a></li>
    </ul>
</div>

<!-- Toggle Button -->
<div id="toggle-btn"><i class="fa-solid fa-bars"></i></div>


<div id="content">

    <!-- Chart -->
    <div class="chart-section card p-3 shadow">
        <canvas id="barangChart"></canvas>
    </div>

    <!-- Search und Filter -->
    <div class="card p-3 shadow mb-3">
        <form method="get" class="d-flex flex-wrap gap-2">
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Cari nama barang atau kategori..." style="min-width:250px;">
            <select name="kategori_filter" class="form-select" style="max-width:200px;">
                <option value="">-- Semua Kategori --</option>
                <?php
                $kategoriResult->data_seek(0);
                while($kt = $kategoriResult->fetch_assoc()): ?>
                    <option value="<?= $kt['nid_kategori']; ?>" <?= ($kt['id_kategori']==$kategoriFilter)?'selected':''; ?>>
                        <?= $kt['nama_kategori']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>
    </div>

    <!-- Barang -->
    <div class="card p-3 shadow mb-4">
        <h5 class="mb-3">Daftar Semua Barang</h5>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID Barang</th>
                    <th>Nama Kategori</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $resultTable->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_barang']; ?></td>
                    <td><?= $row['id_kategori']; ?></td>
                    <td><?= $row['nama_barang']; ?></td>
                    <td><?= $row['jumlah']; ?></td>
                    <td><?= number_format($row['harga'],0,',','.'); ?></td>
                    <td><?= $row['tglmasuk']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- CJS -->
<script>
const sidebar = document.getElementById("sidebar");
const content = document.getElementById("content");
const toggleBtn = document.getElementById("toggle-btn");

toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
    content.classList.toggle("collapsed");
});

const ctx = document.getElementById('barangChart').getContext('2d');
const barangChart = new Chart(ctx, {
    type: 'bar', 
    data: {
        labels: <?= json_encode($namaData); ?>,
        datasets: [{
            label: 'Jumlah Barang',
            data: <?= json_encode($jumlahData); ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.9)', // lebih solid
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1,
            borderRadius: 0,         
            maxBarThickness: 60,     
            barPercentage: 0.8,
            categoryPercentage: 0.8
        }]
    },
    options: {
        responsive:true,
        maintainAspectRatio:false,
        plugins: {
            legend: { display:false },
            title: { display:true, text:'Jumlah per Barang' }
        },
        scales: {
            x: { title: { display: true, text: 'Nama Barang' } },
            y: { beginAtZero:true, title: { display: true, text: 'Jumlah' } }
        }
    }
});
</script>

</body>
</html>
