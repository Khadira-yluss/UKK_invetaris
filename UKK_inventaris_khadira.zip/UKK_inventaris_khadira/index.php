<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID barang tidak ditemukan!'); window.location='item.php';</script>";
    exit;
}

$id = intval($_GET['id']);

// Ambil data barang
$query = mysqli_query($conn, "SELECT * FROM barang WHERE id_barang = $id");
$barang = mysqli_fetch_assoc($query);

if (!$barang) {
    echo "<script>alert('Data barang tidak ditemukan!'); window.location='item.php';</script>";
    exit;
}

// Ambil kategori
$kategori = mysqli_query($conn, "SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Barang</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card p-4 shadow-lg">
        <h3 class="mb-4 text-center">Edit Data Barang</h3>

        <form method="POST" action="update.php">

            <input type="hidden" name="id_barang" value="<?= $barang['id_barang']; ?>">

            <!-- KATEGORI -->
            <label class="form-label">Kategori</label>
            <select name="id_kategori" class="form-select" required>
                <option value="">-- Pilih Kategori --</option>

                <?php while ($kt = mysqli_fetch_assoc($kategori)): ?>
                    <option value="<?= $kt['id_kategori']; ?>"
                        <?= ($barang['id_kategori'] == $kt['id_kategori']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($kt['id_kategori']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <!-- NAMA BARANG -->
            <label class="form-label mt-3">Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control"
                   value="<?= htmlspecialchars($barang['nama_barang']); ?>" required>

            <!-- JUMLAH -->
            <label class="form-label mt-3">Jumlah</label>
            <input type="number" name="jumlah" class="form-control"
                   value="<?= htmlspecialchars($barang['jumlah']); ?>" required>

            <!-- HARGA -->
            <label class="form-label mt-3">Harga</label>
            <input type="text" name="harga" class="form-control"
                   value="<?= htmlspecialchars($barang['harga']); ?>" required>

            <!-- TANGGAL -->
            <label class="form-label mt-3">Tanggal Masuk</label>
            <input type="date" name="tglmasuk" class="form-control"
                   value="<?= htmlspecialchars($barang['tglmasuk']); ?>" required>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    Simpan Perubahan
                </button>
                <a href="item.php" class="btn btn-secondary">Kembali</a>
            </div>

        </form>

    </div>
</div>

</body>
</html>
