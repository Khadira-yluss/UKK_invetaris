<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); 

    
    $cek = mysqli_query($conn, "SELECT * FROM barang WHERE id_barang = $id");
    if (mysqli_num_rows($cek) == 0) {
        echo "<script>alert('Data barang tidak ditemukan!'); window.location='item.php';</script>";
        exit();
    }

    $delete = mysqli_query($conn, "DELETE FROM barang WHERE id_barang = $id");

    if ($delete) {
        echo "<script>alert('Barang berhasil dihapus!'); window.location='item.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus barang!'); window.location='item.php';</script>";
    }
}
?>
