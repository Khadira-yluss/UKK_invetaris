<?php
include "koneksi.php";

// Ambil data search & filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : "";
$kategoriFilter = isset($_GET['kategori_filter']) ? mysqli_real_escape_string($conn, $_GET['kategori_filter']) : "";

// Jika tombol export ditekan → redirect sebelum HTML
if(isset($_GET['export'])){
    $exportType = $_GET['export'];

    if($exportType == 'excel'){
        header("Location: excel.php?search=".urlencode($search)."&kategori_filter=".urlencode($kategoriFilter));
        exit;
    } 
    elseif($exportType == 'pdf'){
        header("Location: pdf.php?search=".urlencode($search)."&kategori_filter=".urlencode($kategoriFilter));
        exit;
    }
}

// Query tabel barang
$where = [];
if ($search != "") $where[] = "(nama_barang LIKE '%$search%' OR nama_kategori LIKE '%$search%')";
if ($kategoriFilter != "") $where[] = "nama_kategori = '$kategoriFilter'";
$whereSql = count($where) > 0 ? "WHERE ".implode(" AND ", $where) : "";

$resultTable = $conn->query("SELECT * FROM barang $whereSql ORDER BY id_barang ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Print / Export Dashboard</title>
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>
/* pastikan toggle terlihat selalu di atas konten */
#toggle-btn {
    position: fixed;
    top: 12px;
    left: 270px;
    z-index: 1200;
    cursor: pointer;
}

/* ruang atas pada konten supaya tidak menutupi toggle */
#content {
    padding-top: 56px; 
    transition: margin-left 0.3s;
}


#sidebar.collapsed ~ #toggle-btn,
#content.collapsed ~ #toggle-btn {
    left: 100px;
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div id="sidebar" class="p-3">
    <h4 class="menu-text">Menu</h4>
    <ul class="nav flex-column mt-4">
        <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span class="menu-text">Dashboard</span></a></li>
        <li><a href="item.php"><i class="fa-solid fa-screwdriver-wrench"></i> <span class="menu-text">Update</span></a></li>
        <li><a href="print.php"><i class="fa-solid fa-file-lines"></i> <span class="menu-text">Print</span></a></li>
        <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span class="menu-text">Logout</span></a></li>
    </ul>
</div>

<!-- Toggle Button -->
<div id="toggle-btn"><i class="fa-solid fa-bars"></i></div>

<!-- CONTENT -->
<div id="content">

<div class="container">
    <h2 class="mb-4">Export Data Dashboard</h2>

    <!-- Form Export -->
    <form method="get" class="mb-4">
        <div class="row g-2 align-items-center">
            <div class="col-auto">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Cari nama barang atau kategori...">
            </div>
            <div class="col-auto">
                <select name="kategori_filter" class="form-select">
                    <option value="">-- Semua Kategori --</option>
                    <?php
                    $kategoriResult = $conn->query("SELECT * FROM kategori");
                    while($kt = $kategoriResult->fetch_assoc()): ?>
                        <option value="<?= $kt['nama_kategori']; ?>" <?= ($kt['nama_kategori']==$kategoriFilter)?'selected':''; ?>>
                            <?= $kt['nama_kategori']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" name="export" value="excel" class="btn btn-success">
                    <i class="fa-solid fa-file-excel"></i> Export Excel
                </button>
            </div>
            <div class="col-auto">
                <button type="submit" name="export" value="pdf" class="btn btn-danger">
                    <i class="fa-solid fa-file-pdf"></i> Export PDF
                </button>
            </div>
        </div>
    </form>

    <!-- Tabel Barang -->
    <div class="card p-3 shadow">
        <h5 class="mb-3">Daftar Barang</h5>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID Barang</th>
                    <th>Nama Kategori</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk/Keluar</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $resultTable->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_barang']; ?></td>
                    <td><?= $row['id_kategori']; ?></td>
                    <td><?= $row['nama_barang']; ?></td>
                    <td><?= $row['jumlah']; ?></td>
                    <td><?= $row['harga']; ?></td>
                    <td><?= isset($row['tgllmasuk']) ? $row['tgllmasuk'] : '-'; ?></td>

                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>

</div>

<!-- JS Sidebar Toggle -->
<script>
    const sidebar = document.getElementById("sidebar");
    const content = document.getElementById("content");
    const toggleBtn = document.getElementById("toggle-btn");

    toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("collapsed");
        content.classList.toggle("collapsed");
    });
</script>

</body>
</html>
