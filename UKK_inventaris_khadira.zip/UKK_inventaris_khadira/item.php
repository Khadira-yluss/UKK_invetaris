<?php
include "koneksi.php";

$kategori = mysqli_query($conn, "SELECT * FROM kategori");


$result = $conn->query("SELECT * FROM barang");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventaris</title>
    <link rel="stylesheet" href="style.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>


    <div id="sidebar" class="p-3">
        <h4 class="menu-text">Menu</h4>

        <ul class="nav flex-column mt-4">
            <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span class="menu-text">Dashboard</span></a></li>
            <li><a href="item.php"><i class="fa-solid fa-screwdriver-wrench"></i> <span class="menu-text">Update</span></a></li>
            <li><a href="print.php"><i class="fa-solid fa-file-lines"></i> <span class="menu-text">Print</span></a></li>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span class="menu-text">Logout</span></a></li>
        </ul>
    </div>

  
    <div id="toggle-btn"><i class="fa-solid fa-bars"></i></div>

    
    <div id="content">

        <h2 class="title">Data Barang</h2>

        <!-- SEARCH UND DROPDOWN KATEGORI -->
        <form class="d-flex mb-3" onsubmit="return false;">

           
            <input type="text" 
                id="search" 
                class="form-control me-2" 
                placeholder="Cari nama barang..." 
                style="min-width: 260px;">

            <!-- Dropdown kategori -->
            <select id="filterKategori" class="form-select" style="max-width: 220px;">
                <option value="">-- Semua Kategori --</option>

                <?php while ($kt = mysqli_fetch_assoc($kategori)) : ?>
                    <option value="<?= $kt['nama_kategori']; ?>">
                        <?= $kt['nama_kategori']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

        </form>

        <!-- TABEL BARANG -->
        <table class="tabel-barang">
            <thead>
                <tr>
                    <th>ID Barang</th>
                    <th>Nama Kategori</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody id="tabelData">
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
    <td><?= $row['id_barang']; ?></td>
    <td><?= $row['id_kategori']; ?></td>
    <td><?= $row['nama_barang']; ?></td>
    <td><?= $row['jumlah']; ?></td>
    <td><?= $row['harga']; ?></td>
    <td><?= $row['tglmasuk']; ?></td>
    <td>
        <a href="edit.php?id=<?= $row['id_barang']; ?>" class="btn btn-sm btn-primary me-1">
            <i class="fa-solid fa-pen-to-square"></i> Edit
        </a>
        <a href="hapus.php?id=<?= $row['id_barang']; ?>"
           class="btn btn-sm btn-danger"
           onclick="return confirm('Yakin ingin hapus?')">
            <i class="fa-solid fa-trash"></i> Hapus
        </a>
    </td>
</tr>

                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="tambah.php" class="btn btn-success mt-3">Tambah Barang</a>
        <a href="kategori.php" class="btn btn-info mt-3">Kelola Kategori</a>

    </div>

    <!-- JS Sidebar Toggle -->
    <script>
        const sidebar = document.getElementById("sidebar");
        const content = document.getElementById("content");
        const toggleBtn = document.getElementById("toggle-btn");

        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("collapsed");
            content.classList.toggle("collapsed");
        });
    </script>

    <!-- FILTER JAVASCRIPT (REALTIME) -->
    <script>
        const searchInput = document.getElementById("search");
        const filterKategori = document.getElementById("filterKategori");
        const tableRows = document.querySelectorAll("table tbody tr");

        searchInput.addEventListener("keyup", filterData);
        filterKategori.addEventListener("change", filterData);

        function filterData() {
            let search = searchInput.value.toLowerCase();
            let kategori = filterKategori.value.toLowerCase();

            tableRows.forEach(row => {
                let namaBarang = row.children[2].textContent.toLowerCase();
                let kategoriRow = row.children[1].textContent.toLowerCase();
                let show = true;

                if (search !== "" && !namaBarang.includes(search)) show = false;
                if (kategori !== "" && kategoriRow !== kategori) show = false;

                row.style.display = show ? "" : "none";
            });
        }
    </script>

</body>
</html>
