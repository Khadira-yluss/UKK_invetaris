<?php
include "koneksi.php";

// ================== TAMBAH KATEGORI ==================
if (isset($_POST['simpan'])) {
    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);

    if ($nama_kategori == "") {
        echo "<script>alert('Nama kategori wajib diisi!');</script>";
    } else {
        // Cek duplikat
        $cek = mysqli_query($conn, "SELECT * FROM kategori WHERE nama_kategori='$nama_kategori'");
        if (mysqli_num_rows($cek) > 0) {
            echo "<script>alert('Kategori sudah ada!');</script>";
        } else {
            $sql = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Kategori berhasil ditambahkan!'); window.location='kategori.php';</script>";
            } else {
                echo "<script>alert('Gagal menyimpan kategori!');</script>";
            }
        }
    }
}

// ================== AMBIL DATA KATEGORI ==================
$result = $conn->query("SELECT * FROM kategori ORDER BY id_kategori ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>CRUD Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2 class="text-center mb-4">CRUD Kategori</h2>

    <!-- FORM TAMBAH KATEGORI -->
    <div class="card mb-4 p-4 shadow">
        <form method="post" class="d-flex gap-2">
            <input type="text" name="nama_kategori" class="form-control" placeholder="Nama kategori" required>
            <button type="submit" name="simpan" class="btn btn-success"><i class="fa-solid fa-plus"></i> Tambah</button>
        </form>
    </div>

    <!-- TABEL KATEGORI -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID Kategori</th>
                <th>Nama Kategori</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id_kategori']; ?></td>
                <td><?= $row['nama_kategori']; ?></td>
                <td>
                    <a href="edit_ktgr.php?id=<?= $row['id_kategori']; ?>" class="btn btn-sm btn-primary me-1">
                        <i class="fa-solid fa-pen-to-square"></i> Edit
                    </a>
                    <a href="hapus_ktgr.php?id=<?= $row['id_kategori']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus?')">
                        <i class="fa-solid fa-trash"></i> Hapus
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<a href="item.php" class="btn btn-info mt-3">Kembali</a>
</body>
</html>
