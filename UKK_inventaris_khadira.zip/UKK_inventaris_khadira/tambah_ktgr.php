<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    $nama_kategori = trim($_POST['nama_kategori']);

    if ($nama_kategori == "") {
        echo "<script>alert('Nama kategori wajib diisi!');</script>";
    } else {
        // Cek apakah kategori sudah ada
        $stmt = $conn->prepare("SELECT id_kategori FROM kategori WHERE nama_kategori = ?");
        $stmt->bind_param("s", $nama_kategori);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Kategori sudah ada!');</script>";
        } else {
            // Insert kategori baru
            $stmt = $conn->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
            $stmt->bind_param("s", $nama_kategori);

            if ($stmt->execute()) {
                echo "<script>
                        alert('Kategori berhasil ditambahkan!');
                        window.location='index.php';
                      </script>";
            } else {
                echo "<script>alert('Gagal menambah kategori!');</script>";
            }
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Kategori</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-4">
  <h2 class="text-center mb-4">Tambah Kategori Baru</h2>
  <div class="card shadow p-4">
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Nama Kategori</label>
        <input type="text" name="nama_kategori" class="form-control" maxlength="35" required>
      </div>
      <div class="text-end">
        <a href="index.php" class="btn btn-secondary">Kembali</a>
        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
      </div>
    </form>
  </div>
</div>

</body>
</html>
