<?php
include "koneksi.php";


if (!isset($_GET['id'])) {
    echo "<script>alert('ID kategori tidak ditemukan!'); window.location='kategori.php';</script>";
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn, "SELECT * FROM kategori WHERE id_kategori='$id'");
if (mysqli_num_rows($query) == 0) {
    echo "<script>alert('Kategori tidak ditemukan!'); window.location='kategori.php';</script>";
    exit;
}

$data = mysqli_fetch_assoc($query);

if (isset($_POST['update'])) {

    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);

    
    if ($nama_kategori == "") {
        echo "<script>alert('Nama kategori wajib diisi!');</script>";
    } else {

        
        $cek = mysqli_query($conn, 
            "SELECT * FROM kategori 
             WHERE nama_kategori='$nama_kategori' AND id_kategori != '$id'"
        );

        if (mysqli_num_rows($cek) > 0) {
            echo "<script>alert('Nama kategori sudah digunakan kategori lain!');</script>";
        } else {

           
            $sql = "UPDATE kategori SET nama_kategori='$nama_kategori' WHERE id_kategori='$id'";

            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Kategori berhasil diperbarui!'); window.location='kategori.php';</script>";
                exit;
            } else {
                echo "<script>alert('Gagal mengupdate kategori!');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body class="bg-light">

<div class="container mt-4">
    <div class="card shadow p-4" style="max-width: 500px; margin:auto;">
        <h3 class="text-center mb-3">Edit Kategori</h3>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">Nama Kategori</label>
                <input type="text" name="nama_kategori" value="<?= $data['nama_kategori']; ?>" class="form-control" required>
            </div>

            <div class="d-flex justify-content-between">
                <a href="kategori.php" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Kembali
                </a>
                <button type="submit" name="update" class="btn btn-primary">
                    <i class="fa-solid fa-save"></i> Update
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
