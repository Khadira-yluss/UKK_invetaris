<?php
session_start();
include "koneksi.php";

// Jika sudah login, langsung ke index
if (isset($_SESSION['id_user'])) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['login'])) {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validasi server-side:
   
    if ($username === '' || preg_match('/\s/', $username)) {
        $error = "Username tidak boleh kosong atau mengandung spasi.";
    } elseif (strlen($password) < 3
        || !preg_match('/[A-Za-z]/', $password)
        || !preg_match('/\d/', $password)
        || !preg_match('/[^A-Za-z0-9]/', $password)
    ) {
        $error = "Password minimal 3 karakter dan harus mengandung huruf, angka, dan simbol.";
    } else {
        // Ambil data user dengan prepared statement untuk keamanan
        $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();

        if ($data) {
            $stored = $data['password'];
            $loginOk = false;

            // Dukungan untuk password hash (password_verify) atau plaintext (fallback)
            if (function_exists('password_verify') && password_verify($password, $stored)) {
                $loginOk = true;
            } elseif ($password === $stored) {
                $loginOk = true;
            }

            if ($loginOk) {
                // SIMPAN SEMUA DATA KE SESSION!
                $_SESSION['id_user']  = $data['id_user'];     // ← PENTING!!
                $_SESSION['username'] = $data['username'];
                $_SESSION['email']    = $data['email'];

                header("Location: index.php");
                exit;
            } else {
                $error = "Password salah!";
            }
        } else {
            $error = "Username tidak ditemukan!";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Login</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
	<link rel="stylesheet" href="style.css">
	<style>
		body { background:#f4f6f9; }
		.login-card { max-width:420px; margin:80px auto; }
		.brand { font-weight:700; letter-spacing:1px; }
		.input-icon { width:42px; text-align:center; background:#e9ecef; border:1px solid #e9ecef; }
	</style>
</head>
<body>

<div class="container">
	<div class="login-card">
		<div class="card shadow-sm">
			<div class="card-body">
				<div class="text-center mb-3">
					<h3 class="brand">Silahkan Login</h3>
					
				</div>

				<?php if(isset($error)): ?>
					<div class="alert alert-danger py-2"><?php echo htmlspecialchars($error); ?></div>
				<?php endif; ?>

				<form id="loginForm" method="POST" novalidate>
					<div class="mb-3 input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-user"></i></span>
						<input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
					</div>

					<div class="mb-3 input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-lock"></i></span>
						<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
					</div>

					<div class="d-grid mb-2">
						<button type="submit" name="login" class="btn btn-primary">Login</button>
					</div>

					<div class="text-center">
						<small class="text-muted">Belum punya akun? <a href="register.php">Register</a></small>
					</div>
				</form>
			</div>
		</div>

		<div class="text-center mt-3 text-muted small">
			&copy; <?= date('Y') ?> Inventaris
		</div>
	</div>
</div>

<script>
// Client-side validation (mirror aturan server)
document.getElementById('loginForm').addEventListener('submit', function(e){
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    const errors = [];
    if (username === '' || /\s/.test(username)) {
        errors.push("Username tidak boleh kosong atau mengandung spasi.");
    }
    if (password.length < 3 || !/[A-Za-z]/.test(password) || !/\d/.test(password) || /[^A-Za-z0-9]/.test(password) === false) {
        errors.push("Password minimal 3 karakter dan harus mengandung huruf, angka, dan simbol.");
    }

    if (errors.length) {
        e.preventDefault();
        alert(errors.join("\n"));
    }
});
</script>

</body>
</html>
