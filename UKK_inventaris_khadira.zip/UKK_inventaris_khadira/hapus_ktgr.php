<?php
include '../config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // pastikan integer

    // Cek apakah id ada di database
    $stmt = $conn->prepare("SELECT * FROM kategori WHERE id_kategori = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $cek = $stmt->get_result();

    if ($cek->num_rows == 0) {
        echo "<script>alert('Kategori tidak ditemukan!'); window.location='index.php';</script>";
        exit();
    }

    // Proses hapus
    $stmt = $conn->prepare("DELETE FROM kategori WHERE id_kategori = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Kategori berhasil dihapus!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus kategori!'); window.location='index.php';</script>";
    }
}
?>
