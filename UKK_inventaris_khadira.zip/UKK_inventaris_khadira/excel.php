<?php
include "koneksi.php";


$search          = isset($_GET['search']) ? trim($_GET['search']) : "";
$kategoriFilter  = isset($_GET['kategori_filter']) ? trim($_GET['kategori_filter']) : "";
$export          = isset($_GET['export']) ? $_GET['export'] : "";



$where = [];
$params = [];

if ($search !== "") {
    $where[] = "(nama_barang LIKE ? OR kategori.nama_kategori LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($kategoriFilter !== "") {
    $where[] = "kategori.id_kategori = ?";
    $params[] = $kategoriFilter;
}

$whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";



$sql = "SELECT barang.*, kategori.nama_kategori 
        FROM barang 
        LEFT JOIN kategori ON barang.id_kategori = kategori.id_kategori
        $whereSql 
        ORDER BY barang.id_barang ASC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();



if ($export === "excel") {

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Data_Barang.xls");

    echo "<table border='1'>
            <tr>
                <th>ID Barang</th>
                <th>Nama Kategori</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Tanggal Masuk</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {

        $kategori = $row['nama_kategori'] ?? '-';
        $tgl = $row['tgllmasuk'] ?? '-';

        echo "<tr>
                <td>{$row['id_barang']}</td>
                <td>{$kategori}</td>
                <td>{$row['nama_barang']}</td>
                <td>{$row['jumlah']}</td>
                <td>{$row['harga']}</td>
                <td>{$tgl}</td>
            </tr>";
    }

    echo "</table>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Print / Export Data Barang</title>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
        color: #222;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .top-btn {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }

    .btn {
        padding: 10px 15px;
        cursor: pointer;
        border: none;
        color: white;
        border-radius: 5px;
        font-size: 14px;
        text-decoration: none;
    }

    .btn-kembali {
        background: #4caf50;
    }

    .btn-kembali:hover {
        background: #45a049;
    }

    .btn-excel {
        background: #2196f3;
    }

    .btn-excel:hover {
        background: #1976d2;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    th {
        background-color: #1e1e1e;
        color: white;
        padding: 10px;
        text-align: center;
    }

    td {
        padding: 8px;
        border: 1px solid #ccc;
        text-align: center;
        background-color: white;
    }
</style>
</head>
<body>

<h2>Data Barang</h2>

<div class="top-btn">
    <a href="print.php" class="btn btn-kembali">Kembali</a>
    <a href="?export=excel&search=<?= urlencode($search) ?>&kategori_filter=<?= urlencode($kategoriFilter) ?>" class="btn btn-excel">Export Excel</a>
</div>

<table>
    <thead>
        <tr>
            <th>ID Barang</th>
            <th>Nama Kategori</th>
            <th>Nama Barang</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
        </tr>
    </thead>

    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['id_barang']) ?></td>
            <td><?= htmlspecialchars($row['nama_kategori'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
            <td><?= htmlspecialchars($row['jumlah']) ?></td>
            <td><?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= htmlspecialchars($row['tgllmasuk'] ?? '-') ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
