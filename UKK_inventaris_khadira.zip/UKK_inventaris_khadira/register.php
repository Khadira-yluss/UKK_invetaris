<?php
session_start();
include 'koneksi.php';

// Jika sudah login, langsung ke index
if (isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

// minimal server-side validation + registration processing
$errors = [];
$name = $email = $username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ambil dan trim input
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // 1) nama: hanya huruf (A-Z, a-z) tanpa spasi atau karakter lain
    if ($name === '' || !preg_match('/^[A-Za-z]+$/', $name)) {
        $errors[] = "Nama harus berisi hanya huruf (A-Z) tanpa spasi atau angka.";
    }

    // 2) email: harus domain @gmail.com dan tidak boleh ada spasi
    if ($email === '' || preg_match('/\s/', $email) || !preg_match('/^[A-Za-z0-9._%+-]+@gmail\.com$/i', $email)) {
        $errors[] = "Email harus menggunakan domain @gmail.com dan tidak boleh ada spasi.";
    }

    // 3) username: tidak boleh ada spasi
    if ($username === '' || preg_match('/\s/', $username)) {
        $errors[] = "Username tidak boleh mengandung spasi dan tidak boleh kosong.";
    }

    // 4) password: minimal 3 karakter dan harus mengandung huruf, angka, dan simbol
    if (strlen($password) < 3
        || !preg_match('/[A-Za-z]/', $password)
        || !preg_match('/\d/', $password)
        || !preg_match('/[^A-Za-z0-9]/', $password)
    ) {
        $errors[] = "Password minimal 3 karakter dan harus mengandung huruf, angka, dan simbol.";
    }

    // Jika tidak ada error, lakukan penyimpanan (prepared statement)
    if (empty($errors)) {
        // cek apakah username/email sudah ada (opsional, tapi aman)
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = "Username atau email sudah terdaftar.";
            $stmt->close();
        } else {
            $stmt->close();
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $ins = $conn->prepare("INSERT INTO users (name, email, username, password) VALUES (?, ?, ?, ?)");
            $ins->bind_param("ssss", $name, $email, $username, $password_hash);
            if ($ins->execute()) {
                // sukses — arahkan atau tampilkan pesan sukses
                header("Location: login.php?registered=1");
                exit;
            } else {
                $errors[] = "Gagal menyimpan data. Silakan coba lagi.";
            }
            $ins->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Daftar Akun</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
	<link rel="stylesheet" href="style.css">
	<style>
		body { background:#f4f6f9; }
		.card-wrap { max-width:480px; margin:70px auto; }
		.brand { font-weight:700; letter-spacing:1px; }
		.input-icon { width:42px; text-align:center; background:#e9ecef; border:1px solid #e9ecef; }
		.password-toggle { cursor:pointer; color:#6c757d; user-select:none; }
		.position-relative input { padding-right:44px; }
		.card { background-color: #fff; }
		.btn-primary { background:#007bff; border-color:#007bff; }
	</style>
</head>
<body>

<div class="container">
	<div class="card-wrap">
		<div class="card shadow-sm">
			<div class="card-body">
				<div class="text-center mb-3">
					<h3 class="brand">Silahkan Daftar</h3>
				</div>

				<?php if (!empty($errors)): ?>
					<div class="alert alert-danger py-2">
						<ul>
						<?php foreach ($errors as $e): ?>
							<li><?= htmlspecialchars($e); ?></li>
						<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<form id="registerForm" method="post" action="">
					<div class="mb-3 input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-user"></i></span>
						<input type="text" name="name" id="name" value="<?= htmlspecialchars($name) ?>" class="form-control" placeholder="Nama Lengkap" required>
					</div>

					<div class="mb-3 input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-envelope"></i></span>
						<input type="email" name="email" id="email" value="<?= htmlspecialchars($email) ?>" class="form-control" placeholder="Email" required>
					</div>

					<div class="mb-3 input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-user-check"></i></span>
						<input type="text" name="username" id="username" value="<?= htmlspecialchars($username) ?>" class="form-control" placeholder="Username" required>
					</div>

					<div class="mb-3 position-relative input-group">
						<span class="input-group-text input-icon"><i class="fa-solid fa-lock"></i></span>
						<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
						<span class="password-toggle mx-2" style="position:absolute; right:10px; top:10px;" onclick="togglePassword('password', this)">👁️</span>
					</div>

					<div class="d-grid mb-2">
						<button type="submit" class="btn btn-primary">Daftar Sekarang</button>
					</div>

					<div class="text-center">
						<small class="text-muted">Sudah punya akun? <a href="login.php">Login</a></small>
					</div>
				</form>
			</div>
		</div>

		<div class="text-center mt-3 text-muted small">
			&copy; <?= date('Y') ?> Inventaris
		</div>
	</div>
</div>

<script>
function togglePassword(id, el) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        el.textContent = "🙈";
    } else {
        input.type = "password";
        el.textContent = "👁️";
    }
}

// Client-side validation (sama aturan dengan server)
document.getElementById('registerForm').addEventListener('submit', function(e){
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    const errors = [];

    if (!/^[A-Za-z]+$/.test(name)) {
        errors.push("Nama harus berisi hanya huruf (A-Z) tanpa spasi atau angka.");
    }
    if (/\s/.test(email) || !/^[A-Za-z0-9._%+-]+@gmail\.com$/i.test(email)) {
        errors.push("Email harus menggunakan domain @gmail.com dan tidak boleh ada spasi.");
    }
    if (/\s/.test(username) || username === '') {
        errors.push("Username tidak boleh mengandung spasi dan tidak boleh kosong.");
    }
    if (password.length < 3 || !/[A-Za-z]/.test(password) || !/\d/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
        errors.push("Password minimal 3 karakter dan harus mengandung huruf, angka, dan simbol.");
    }

    if (errors.length) {
        e.preventDefault();
        alert(errors.join("\n"));
    }
});
</script>

</body>
</html>
